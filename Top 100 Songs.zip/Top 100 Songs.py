# -*- coding: utf-8 -*-
"""
Created on Thu Oct 20 19:46:07 2022

@author: mmfor
"""

import matplotlib.pyplot as plt
import pandas as pd  # (this is for reading a csv file)
from pandas import DataFrame as df
import datetime as dt
import numpy as np
import matplotlib.dates as mdates
import glob
import os
import seaborn as sns
#%%
#read in files
file= 'C:/Users/mmfor/Downloads/Python Data Sets/Spotify 2010 - 2019 Top 100.csv'
header=['title','artist','genre','year','added','bpm','energy','dance','decibel','live','val','duration','acous','speech','pop','topyear','artisttype']
dataold=pd.read_csv(file,names=header,skiprows=1,header= None)
data=pd.read_csv(file,names=header,skiprows=1,header= None, usecols=[3,5,6,7,8,9,10,11,12,13,14,15]) #usecols=[3,5,6,7,8,9,10,11,12,13,14,15]

#%%
sns.set(font_scale=1)
plt.figure()
sns.histplot(data=data,x=data.year)
plt.xlabel('Year Released')
plt.ylabel('Count')
plt.title('Release Year for all Top Songs from 2010-2019')
#%%
correlation=data.corr()
plt.figure()
sns.heatmap(data=correlation,annot = True, vmin=-1,vmax=1)
plt.title('Correlation Map of Top Song Factors')

#%%
#distribution data for year released vs top year

sns.displot(data=data,x=data.topyear,hue=data.year,hue_norm=(2009,2021),palette='rainbow',multiple='stack',height=10)
plt.title('Top Year and Year Written')
#%%

sns.displot(x=data.decibel,y=data.energy, kind='kde', rug = True)

#%%

data13 = dataold[dataold.topyear == 2013]




#%%
sns.set(font_scale=.8)
plt.figure(1)
plt.subplot(3,3,1)
sns.boxplot( x=data.topyear, y=data.bpm,palette='rainbow')
plt.subplot(3,3,2)
sns.boxplot(x=data.topyear,y=data.energy,palette='rainbow')
plt.subplot(3,3,3)
sns.boxplot(x=data.topyear,y=data.dance,palette='rainbow')
plt.subplot(3,3,4)
sns.boxplot(x=data.topyear,y=data.decibel,palette='rainbow')
plt.subplot(3,3,5)
sns.boxplot(x=data.topyear,y=data.live,palette='rainbow') 
plt.subplot(3,3,6)
sns.boxplot(x=data.topyear,y=data.val,palette='rainbow')
plt.subplot(3,3,7)
sns.boxplot(x=data.topyear,y=data.duration,palette='rainbow')
plt.subplot(3,3,8)
sns.boxplot(x=data.topyear,y=data.acous,palette='rainbow')
plt.subplot(3,3,9)
sns.boxplot(x=data.topyear,y=data.speech,palette='rainbow')



#%%
'''
Search and replace the genre names with more generic versions (Ex. 'electro pop' to 'pop') 
'''
dataold.genre.fillna('',inplace=True)
dataold.loc[dataold.genre.str.contains('rap'),'genre']='rap'
dataold.loc[dataold.genre.str.contains('hip hop'),'genre']='hip hop'
dataold.loc[dataold.genre.str.contains('rock'),'genre']='rock'
dataold.loc[dataold.genre.str.contains('dance|disco'),'genre']='dance/disco'
dataold.loc[dataold.genre.str.contains('indie'),'genre']='indie'
dataold.loc[dataold.genre.str.contains('country'),'genre']='country'
dataold.loc[dataold.genre.str.contains('r&b'),'genre']='R&B'
dataold.loc[dataold.genre.str.contains('contemporary'),'genre']='contemporary'
dataold.loc[dataold.genre.str.contains('pop'),'genre']='pop'
dataold.loc[~dataold.genre.str.contains('pop|rap|hip hop|rock|dance/disco|indie|country|R&B|contemporary'),'genre']='miscellaneous'

#%%
sns.set(font_scale=.8)
plt.figure()
plt.subplot(2,1,1)
sns.histplot(data=dataold,x='genre',multiple='dodge',hue='topyear',shrink=.8,palette='rainbow') #top year where it was na was replace with a blank due to our previous code. Help
plt.title('Genres of Top 100 Songs with Top Year')

plt.subplot(2,1,2)
sns.histplot(data=dataold,x='artisttype',multiple='dodge',hue='topyear',shrink=.8,palette='rainbow') #top year where it was na was replace with a blank due to our previous code. Help
plt.title('Artist Type of 100 Top Songs 2010-2019')
#sns.histplot(data=dataold.genre,stat='percent',discrete=True)

#%%
'''
'''
#Here begins the 'what the fuck 2013?' section of this code
'''
plt.figure()
plt.subplot(4,2,1)
plt.scatter(data13.energy,data13.bpm)
plt.title('energy/bpm')
plt.subplot(4,2,2)
plt.scatter(data13.energy,data13.duration)
plt.title('energy/duration')
plt.subplot(4,2,3)
plt.scatter(data13.energy,data13.dance)
plt.title('energy/dance')
plt.subplot(4,2,4)
plt.scatter(data13.energy,data13.decibel)
plt.title('energy/decibel')
#Energy vs decibel level has a mild positive correlation
plt.subplot(4,2,5)
plt.scatter(data13.energy,data13.live)
plt.title('energy/liveliness')
plt.subplot(4,2,6)
plt.scatter(data13.energy,data13.val)
plt.title('energy/val')
plt.subplot(4,2,7)
plt.scatter(data13.energy,data13.acous)
plt.title('energy/acous')
plt.subplot(4,2,8)
plt.scatter(data13.energy,data13.speech)
plt.title('energy/speech')
'''
#%%
#brief aside from wtf 2013? 

dataquiet=data[data.decibel > -5]
dataloud=data[data.decibel < -3]

correlationq=dataquiet.corr()
correlationl=dataloud.corr()
plt.figure()
plt.subplot(1,2,1)
sns.heatmap(data=correlationq,annot=True,vmin=-1,vmax=1)
plt.title('Quiet')
plt.subplot(1,2,2)
sns.heatmap(data=correlationl,annot=True,vmin=-1,vmax=1)
plt.title('loud')
#conclusion: deicbel does not determine the energy on quiet music but, it does determine the energy on loud music.
#%%
#pair plots by beloved
#sns.pairplot(data=data) do not run Sarah, it hurts your computer
